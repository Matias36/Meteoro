const ANCHO = 400;
const ALTO = 600;
const Y_ESTRELLA = 530;  // altura fija de la estrella en el mundo compartido
const RADIO = 22;

let estrellaX = 0.5;     // 0 = izquierda, 1 = derecha
let ultimoEnvio = 0;

function setup() {
  const lienzo = createCanvas(ANCHO, ALTO);
  lienzo.parent('juego');
}

function draw() {
  background(10, 7, 51);
  if (!rol) return;

  // el esquivador mueve la estrella con el mouse o el dedo
  if (rol === 'esquivador') {
    estrellaX = constrain(mouseX / ANCHO, 0, 1);
    if (millis() - ultimoEnvio > 33) {
      socket.emit('mover', estrellaX);
      ultimoEnvio = millis();
    }
  }

  dibujarEstrella(estrellaX * ANCHO, aPantallaY(Y_ESTRELLA), RADIO);

  fill(255, 243, 196);
  noStroke();
  textAlign(CENTER);
  textSize(16);
  text('Rol: ' + rol, ANCHO / 2, 24);
}

  // meteoritos
  fill(255, 120, 170);
  noStroke();
  for (const [, mx, my] of meteoritos) {
    circle(mx, aPantallaY(my), RADIO_METEORITO * 2);
  }

  // guía del deslizamiento del lanzador
  if (inicioSwipe && rol === 'lanzador') {
    stroke(255, 255, 255, 120);
    strokeWeight(3);
    line(inicioSwipe.x, inicioSwipe.y, mouseX, mouseY);
  }

  // aviso de quién destruyó la estrella
  if (Date.now() < mensajeHasta) {
    noStroke();
    fill(255);
    textSize(22);
    textAlign(CENTER);
    text(mensaje, ANCHO / 2, ALTO / 2);
  }

// mundo -> pantalla: el lanzador ve todo invertido verticalmente
function aPantallaY(yMundo) {
  return rol === 'lanzador' ? ALTO - yMundo : yMundo;
}

function dibujarEstrella(x, y, r) {
  push();
  translate(x, y);
  fill(255, 217, 77);
  stroke(255, 240, 150);
  strokeWeight(3);
  beginShape();
  for (let i = 0; i < 10; i++) {
    const ang = -HALF_PI + (i * PI) / 5;
    const rad = i % 2 === 0 ? r : r * 0.5;
    vertex(cos(ang) * rad, sin(ang) * rad);
  }
  endShape(CLOSE);
  pop();
}

function mousePressed() {
  if (rol !== 'lanzador') return;
  if (mouseX < 0 || mouseX > ANCHO || mouseY < 0 || mouseY > ALTO) return;
  inicioSwipe = { x: mouseX, y: mouseY };
}

function mouseReleased() {
  if (!inicioSwipe) return;
  const dxPantalla = mouseX - inicioSwipe.x;
  const dyPantalla = mouseY - inicioSwipe.y;
  const largo = Math.hypot(dxPantalla, dyPantalla);

  if (largo > 20) {  // ignora toques sin deslizar
    socket.emit('lanzar', {
      x: constrain(inicioSwipe.x / ANCHO, 0, 1),
      dx: dxPantalla,
      dy: -dyPantalla,  // la pantalla del lanzador está invertida
      fuerza: constrain(largo / 250, 0, 1),
    });
  }
  inicioSwipe = null;
}
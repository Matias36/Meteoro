const express = require('express');
const https = require('https');
const fs = require('fs');
const { Server } = require('socket.io');


const app = express();
const server = https.createServer(
  {
    key: fs.readFileSync('certs/clave.pem'),
    cert: fs.readFileSync('certs/certificado.pem'),
  },
  app
);
const io = new Server(server);

const ANCHO = 400, ALTO = 600;      // mismas medidas que sketch.js
const Y_ESTRELLA = 530;
const RADIO_ESTRELLA = 22;          // igual que RADIO en sketch.js
const RADIO_METEORITO = 14;
const VEL_MIN = 120, VEL_MAX = 380; // píxeles por segundo
const ESPERA_LANZAR = 700;          // ms entre lanzamientos de cada jugador
const PAUSA_DESTRUIDA = 3000;       // ms de pausa tras destruir la estrella
const MAX_METEORITOS = 40;

let meteoritos = [];         // cada uno: [id, x, y]
let mensaje = '';
let mensajeHasta = 0;
let inicioSwipe = null;      // dónde empezó el deslizamiento (en pantalla)





app.use(express.static('public'));

// salas['nombre'] = { esquivador: socketId | null, jugadores: Set de socketId }
const salas = {};

io.on('connection', (socket) => {
  socket.on('unirse', ({ sala: nombreSala, nombre } = {}) => {
    if (socket.data.sala) return; // ya está en una sala

    nombreSala = String(nombreSala || '').trim().slice(0, 20);
    nombre = String(nombre || '').trim().slice(0, 15);
    if (!nombreSala || !nombre) return;

    // el nombre no puede repetirse dentro de la sala
    const salaExistente = salas[nombreSala];
    if (salaExistente) {
      for (const id of salaExistente.jugadores) {
        const otro = io.sockets.sockets.get(id);
        if (otro && otro.data.nombre.toLowerCase() === nombre.toLowerCase()) {
          socket.emit('errorNombre', 'Ese nombre ya está en uso en la sala');
          return;
        }
      }
    }

    socket.on('meteoritos', (lista) => {
  meteoritos = lista;
});

socket.on('destruida', ({ autor }) => {
  meteoritos = [];
  mensaje = autor + ' destruyó la estrella';
  mensajeHasta = Date.now() + 3000;
});

    socket.data.nombre = nombre;
    socket.join(nombreSala);
    socket.data.sala = nombreSala;

    if (!salas[nombreSala]) {
      salas[nombreSala] = { esquivador: null, jugadores: new Set() };
    }
    const salaActual = salas[nombreSala];
    salaActual.jugadores.add(socket.id);

    // el primero en entrar es esquivador, los demás lanzadores
    let rol = 'lanzador';
    if (!salaActual.esquivador) {
      salaActual.esquivador = socket.id;
      rol = 'esquivador';
    }
    socket.data.rol = rol;

    socket.emit('rol', rol);
    io.to(nombreSala).emit('jugadores', salaActual.jugadores.size);
  });

      socket.on('mover', (x) => {
    if (socket.data.rol !== 'esquivador') return;
    if (!Number.isFinite(x)) return;
    const sala = salas[socket.data.sala];
    if (!sala) return;
    x = Math.max(0, Math.min(1, x));
    sala.estrellaX = x;
    socket.to(socket.data.sala).volatile.emit('estrella', x);
  });

    socket.on('lanzar', (d) => {
    const sala = salas[socket.data.sala];
    if (!sala || socket.data.rol !== 'lanzador' || !d) return;

    const ahora = Date.now();
    if (ahora < sala.pausaHasta) return;
    if (ahora < (socket.data.proximo || 0)) return;
    if (sala.meteoritos.length >= MAX_METEORITOS) return;

    let { x, dx, dy, fuerza } = d;
    if (![x, dx, dy, fuerza].every(Number.isFinite)) return;

    x = Math.max(0, Math.min(1, x));
    fuerza = Math.max(0, Math.min(1, fuerza));

    // dirección normalizada; siempre avanza hacia la estrella
    const largo = Math.hypot(dx, dy);
    if (largo < 0.001) return;
    let ux = dx / largo;
    let uy = Math.max(dy / largo, 0.3);
    const n = Math.hypot(ux, uy);
    ux /= n;
    uy /= n;

    const vel = VEL_MIN + fuerza * (VEL_MAX - VEL_MIN);
    sala.meteoritos.push({
      id: sala.siguienteId++,
      x: x * ANCHO,
      y: 0,
      vx: ux * vel,
      vy: uy * vel,
      autor: socket.data.nombre,
    });
    socket.data.proximo = ahora + ESPERA_LANZAR;
  });


  socket.on('disconnect', () => {
    const nombreSala = socket.data.sala;
      salas[nombreSala] = {
        esquivador: null,
        jugadores: new Set(),
        estrellaX: 0.5,
        meteoritos: [],
        siguienteId: 1,
        pausaHasta: 0,
      };
    if (!sala) return;

    sala.jugadores.delete(socket.id);

    // sala vacía: se elimina
    if (sala.jugadores.size === 0) {
      delete salas[nombreSala];
      return;
    }

    // si se fue el esquivador, pasa a serlo el siguiente
    if (sala.esquivador === socket.id) {
      const siguienteId = sala.jugadores.values().next().value;
      sala.esquivador = siguienteId;
      const siguiente = io.sockets.sockets.get(siguienteId);
      if (siguiente) {
        siguiente.data.rol = 'esquivador';
        siguiente.emit('rol', 'esquivador');
      }
    }

    io.to(nombreSala).emit('jugadores', sala.jugadores.size);
  });
});

// movimiento y colisiones, 60 veces por segundo
let ultimo = Date.now();
setInterval(() => {
  const ahora = Date.now();
  const dt = Math.min(0.05, (ahora - ultimo) / 1000);
  ultimo = ahora;

  for (const [nombreSala, sala] of Object.entries(salas)) {
    if (ahora < sala.pausaHasta) continue;
    const estrellaPx = sala.estrellaX * ANCHO;

    for (const m of sala.meteoritos) {
      m.x += m.vx * dt;
      m.y += m.vy * dt;
      if (Math.hypot(m.x - estrellaPx, m.y - Y_ESTRELLA) < RADIO_ESTRELLA + RADIO_METEORITO) {
        io.to(nombreSala).emit('destruida', { autor: m.autor });
        sala.meteoritos = [];
        sala.pausaHasta = ahora + PAUSA_DESTRUIDA;
        break;
      }
    }

    // quitar los que salieron del mundo
    sala.meteoritos = sala.meteoritos.filter(
      (m) => m.y < ALTO + 50 && m.x > -50 && m.x < ANCHO + 50
    );
  }
}, 1000 / 60);

// enviar los meteoritos a cada sala, 30 veces por segundo
setInterval(() => {
  for (const [nombreSala, sala] of Object.entries(salas)) {
    io.to(nombreSala).volatile.emit(
      'meteoritos',
      sala.meteoritos.map((m) => [m.id, Math.round(m.x), Math.round(m.y)])
    );
  }
}, 1000 / 30);


server.listen(3000, () => console.log('Servidor en https://localhost:3000'));
// ===== 1. Utilidades y estado =====
const $ = s => document.querySelector(s);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const cl = (v, a, b) => Math.max(a, Math.min(b, v));

const socket = io();
let me = null, themeName = '', pick = 'orbita', ros = [], cfg, scene;
let role = '', phase = 'waiting', lastP = '', st = { n: 1 };
let cam = false, act = () => { };
let until = 0;


// ===== 2. Pantallas (cartel central) =====
const show = (t, d, b, a, skip) => {
  $('#t').textContent = t;
  $('#d').textContent = d;
  $('#btn').textContent = b;
  $('#btn').disabled = false;
  act = a;
  $('#skip').hidden = !skip;
  $('#ov').hidden = false;
};
const draw = () => socket.emit('draw');
const ready = () => socket.emit('ready');
$('#btn').onclick = () => act();
$('#skip').onclick = () => socket.emit('pass');

const lobby = () => show(
  'Sorteo de piloto',
  `Hay ${st.n} en este universo. El sorteo elige quién esquiva frente a la cámara; todos los demás tiran meteoritos. Pueden entrar más personas en cualquier momento.`,
  'Sortear piloto', draw
);


// ===== 3. Cámara y detección de pose =====
let pose = null,
 noseX = .5,
  neutral = .5,
  present = false,
  steer = 0,
  lastVideo = -1,
  lastTs = 0;

  const RANGO_BASE = .40;
  const RANGO_POR_ETAPA = .05;
  const RANGO_MIN = .08;
  const rangoActual = () => Math.max(RANGO_MIN, RANGO_BASE - RANGO_POR_ETAPA * (st.et || 0));

async function loadPose() {
  if (pose) return;
  const { FilesetResolver, PoseLandmarker } = await import('/mediapipe/vision_bundle.mjs');
  const files = await FilesetResolver.forVisionTasks('/mediapipe/wasm');
  const make = delegate => PoseLandmarker.createFromOptions(files, {
    baseOptions: { modelAssetPath: '/models/pose_landmarker_lite.task', delegate },
    runningMode: 'VIDEO',
    numPoses: 1
  });
  try { pose = await make('GPU'); } catch (e) { pose = await make('CPU'); }
}

function detect() {
  const v = $('#vid');
  if (!pose || v.readyState < 2) return false;
  if (v.currentTime !== lastVideo) {
    lastVideo = v.currentTime;
    lastTs = Math.max(performance.now(), lastTs + 1);
    const n = pose.detectForVideo(v, lastTs).landmarks[0]?.[0];
    present = !!n && (n.visibility ?? 1) > .5;
    if (present) noseX = 1 - n.x;
  }
  return true;
}


function intro() {
  show('¡Te tocó esquivar!', 'Usamos tu cámara para seguir tu cabeza', 'Activar cámara', wiz, true);
}

async function wiz() {
  $('#btn').disabled = true;
  $('#d').textContent = 'Abriendo cámara y cargando el detector…';
  try {
    $('#vid').srcObject = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480, facingMode: 'user' }, audio: false });
    await $('#vid').play();
  } catch (e) {
    $('#btn').disabled = false;
    $('#d').textContent = 'No pude abrir la cámara. Podés usar las flechas del teclado, o pasar el turno.';
    return;
  }
  try { await loadPose(); }
  catch (e) {
    $('#btn').disabled = false;
    $('#d').textContent = 'No pude cargar el detector de pose. Podés reintentar, usar las flechas del teclado, o pasar el turno.';
    return;
  }
  cam = true;
  $('#cam').hidden = false;
  ready();
}


// ===== 4. Control de la nave (piloto) =====
let keyX = 0, shipL = 0, lastSent = 9, lastT = 0;
const keys = {}, dt = .033;

addEventListener('keydown', e => { keys[e.key] = 1; });
addEventListener('keyup', e => { keys[e.key] = 0; });

setInterval(() => {
  if (!scene || role !== 'pilot') return;
  let x = null;
  const kd = (keys.ArrowRight ? 1 : 0) - (keys.ArrowLeft ? 1 : 0);
  if (kd) {
    keyX = cl(keyX + kd * dt * 1.8, -1, 1);
    x = keyX;
  } else if (cam && detect()) {
    if (present) steer += (cl((noseX - neutral) / rangoActual(), -1, 1) - steer) * .4;
    x = steer;
    keyX = steer;
    $('#mk').style.left = noseX * 100 + '%';
  }
  if (x === null) return;
  shipL += cl(x * cfg.SHIP_LIM - shipL, -cfg.SHIP_MAX_SPEED * dt, cfg.SHIP_MAX_SPEED * dt);
  scene.setLocalShip(shipL);
  const n = performance.now();
  if (Math.abs(x - lastSent) > .004 || n - lastT > 250) {
    socket.emit('steer', x);
    lastSent = x;
    lastT = n;
  }
}, 33);


// ===== 5. Lanzamiento de meteoritos (tiradores) =====
const HOLD = 800;
let aim = -1, t0 = 0, hover = -1;
const cvEl = $('#cv');

const laneOf = e => {
  const r = cvEl.getBoundingClientRect();
  return scene.laneAt(e.clientX - r.left, e.clientY - r.top);
};
const charge = () => aim < 0 ? 0 : Math.min(1, (performance.now() - t0) / HOLD);
const cooling = () => performance.now() < until;

cvEl.addEventListener('pointerdown', e => {
  if (role !== 'thrower' || phase !== 'playing' || cooling()) return;
  e.preventDefault();
  cvEl.setPointerCapture(e.pointerId);
  aim = laneOf(e);
  t0 = performance.now();
});
cvEl.addEventListener('pointermove', e => {
  if (role !== 'thrower') return;
  const l = laneOf(e);
  if (aim >= 0) aim = l;
  else hover = e.pointerType === 'mouse' ? l : -1;
});
cvEl.addEventListener('pointerleave', () => { if (aim < 0) hover = -1; });
cvEl.addEventListener('contextmenu', e => e.preventDefault());

function release(send) {
  if (aim < 0) return;
  const lane = aim, k = charge();
  aim = -1;
  if (!send || phase !== 'playing' || cooling()) return;
  const speed = 1 + Math.round(k * 9), wait = cfg.COOLDOWN_BASE + speed * cfg.COOLDOWN_PER;
  until = performance.now() + wait;
  const cd = $('#cd');
  cd.style.transition = 'none';
  cd.style.width = '100%';
  cd.offsetWidth;
  cd.style.transition = `width ${wait}ms linear`;
  cd.style.width = '0';
  socket.emit('throw', { lane, speed }, r => { if (!r.ok && r.wait) until = performance.now() + r.wait; });
}
cvEl.addEventListener('pointerup', () => release(true));
cvEl.addEventListener('pointercancel', () => release(false));

setInterval(() => {
  if (!scene) return;
  const press = aim >= 0;
  scene.setAim(press ? aim : (role === 'thrower' && phase === 'playing' ? hover : -1), charge(), press, cooling());
}, 33);


// ===== 6. Entrada a la sala y temas =====
const dots = h => h.map(x => `<i style="background:hsl(${x},90%,62%)"></i>`).join('');

function buildThemes() {
  const T = $('#ths');
  T.innerHTML = '';
  for (const k in cfg.THEMES) {
    const b = document.createElement('button');
    b.className = 'th' + (k === pick ? ' on' : '');
    b.dataset.k = k;
    b.innerHTML = `${cfg.THEMES[k].n}<br>${dots(cfg.THEMES[k].h.slice(0, 5))}`;
    b.onclick = () => { pick = k; buildThemes(); };
    T.appendChild(b);
  }
}

function applyTheme(k) {
  const t = cfg.THEMES[k] || cfg.THEMES.orbita;
  themeName = t.n;
  scene.setTheme(t);
  document.body.style.background = t.bg[0];
}

function showEntry(err) {
  $('#ov').hidden = true;
  $('#roster').hidden = true;
  $('#pan').hidden = true;
  $('#cam').hidden = true;
  $('#entry').hidden = false;
  $('#err').textContent = err || '';
  scene.setState({ p: 'waiting', sx: 0, l: cfg.LIVES, s: 0, b: 0, cd: 0, inv: false, m: [], pn: '' });
  scene.setLocalShip(null);
  socket.emit('rooms', list => {
    const A = $('#act');
    A.innerHTML = '';
    list.forEach(r => {
      const b = document.createElement('button');
      b.className = 'th';
      b.textContent = `${r.code} · ${cfg.THEMES[r.theme].n} · ${r.n}`;
      b.onclick = () => { $('#rm').value = r.code; pick = r.theme; buildThemes(); };
      A.appendChild(b);
    });
  });
}

function enter(a) {
  socket.emit('enter', a, r => {
    if (!r.ok) { me = null; return showEntry(r.msg); }
    me = { name: r.name, room: r.room, theme: r.theme };
    applyTheme(r.theme);
    $('#entry').hidden = true;
    $('#roster').hidden = false;
  });
}

$('#go').onclick = () => enter({ name: $('#nm').value, room: $('#rm').value, theme: pick });
$('#lv').onclick = () => { socket.emit('leave'); me = null; role = ''; lastP = ''; showEntry(); };


// ===== 7. Lista de jugadores y ranking =====
$('#rh').onclick = () => $('#rb').hidden = !$('#rb').hidden;
if (innerWidth < 600) $('#rb').hidden = true;

function rankText() {
  const r = ros.filter(p => !p.pilot && p.hits > 0).sort((a, b) => b.hits - a.hits).slice(0, 3);
  return r.length ? ' Ranking: ' + r.map((p, i) => `${i + 1}. ${p.name} (${p.hits})`).join(' · ') + '.' : '';
}

socket.on('roster', P => {
  ros = P;
  $('#rt').textContent = `Jugadores (${P.length})`;
  const L = $('#rl');
  L.innerHTML = '';
  [...P].sort((a, b) => b.pilot - a.pilot || b.hits - a.hits).forEach(p => {
    const li = document.createElement('li'), a = document.createElement('span'), b = document.createElement('span');
    a.textContent = (p.pilot ? '🧑‍🚀 ' : '🚀 ') + p.name;
    b.textContent = p.pilot ? 'piloto' : p.hits;
    if (p.id === socket.id) li.className = 'me';
    li.append(a, b);
    L.appendChild(li);
  });
});


// ===== 8. Eventos del servidor =====
socket.on('welcome', c => {
  cfg = c;
  if (!scene) {
    scene = Scene.create($('#cv'), { cfg: c });
    scene.start();
    buildThemes();
  }
  if (me) enter(me); else showEntry();
});

socket.on('role', r => {
  role = r;
  $('#entry').hidden = true;
  $('#pan').hidden = r !== 'thrower';
  $('#cam').hidden = !(r === 'pilot' && cam);
  shipL = 0;
  if (r !== 'pilot') scene.setLocalShip(null);
  if (r === 'lobby') lobby();
  else if (r === 'thrower') $('#ov').hidden = true;
  else if (cam) ready();
  else intro();
});

socket.on('hit', () => scene.hit());
socket.on('scored', d => $('#hits').textContent = d.hits);

socket.on('state', s => {
  st = s;
  scene.setState(s);
  phase = s.p;
  $('#chip').textContent = me ? `${themeName} · ${me.room} · ${s.n} ${s.n === 1 ? 'jugador' : 'jugadores'}` : '';
  cvEl.style.cursor = role === 'thrower' && s.p === 'playing' ? 'crosshair' : 'default';
  $('#msg').textContent = role === 'thrower' && s.p === 'waiting' ? (s.pilot ? `${s.pn} se está preparando…` : '') : '';
  if (s.p !== lastP) {
    lastP = s.p;
    if (s.p === 'countdown' || s.p === 'playing') $('#ov').hidden = true;
    if (s.p === 'over') show('Fin del viaje', `${s.pn} aguantó ${(s.s / 10).toFixed(1)} s (mejor: ${(s.b / 10).toFixed(1)} s).${rankText()} ¿Sorteamos de nuevo?`, 'Sortear de nuevo', draw);
  }
});